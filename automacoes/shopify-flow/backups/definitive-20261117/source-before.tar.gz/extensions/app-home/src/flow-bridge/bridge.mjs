import {locationId, project, eventFor, authoritativeStatus, metafieldValues, claimNotification, confirmNotification, decisionVersion, NAMESPACE, STATUSES} from './state.mjs';
import {READ, SET, SIGNAL} from './operations.mjs';
import {newUuid} from './uuid.mjs';

function error(message, code) { return Object.assign(new Error(message), {code}); }

export function createBridge({query, loadAuthoritative, classify, enabled = false, emitSignals = false, now = () => new Date().toISOString(), uuid = newUuid}) {
  async function read(id) {
    locationId(id);
    const {companyLocation: local} = await query(READ, {id});
    if (!local || local.id !== id) throw Error('Local indisponivel para sincronizacao.');
    const state = local.review ? JSON.parse(local.review.value) : null;
    if (local.review && (!state || typeof state !== 'object' || Array.isArray(state) || local.review.type !== 'json' || state.schema !== 1 || state.locationId !== id || !local.review.compareDigest || typeof state.ready !== 'boolean' || (!STATUSES.includes(state.status) && !(state.status === null && !state.ready)))) throw Error('Espelho invalido.');
    if (state?.cycleId && (!/^[a-zA-Z0-9-]{1,80}$/.test(state.cycleId) || !Number.isFinite(Date.parse(state.enteredAt)))) throw Error('Ciclo de analise invalido.');
    if (state?.ready && state.status === 'pendente' && !state.cycleId) throw Error('Cadastro pendente sem ciclo verificavel.');
    if (!state && [local.ready, local.status, local.cycle, local.entered].some(Boolean)) throw Error('Espelho parcial; sincronizacao requer revisao.');
    if (state?.ready && (local.ready?.value !== 'true' || local.status?.value !== state.status || local.cycle?.value !== (state.cycleId || 'none') || (state.enteredAt && Date.parse(local.entered?.value) !== Date.parse(state.enteredAt)))) throw Error('Metafields divergentes; notificacao bloqueada.');
    const ledger = local.ledger ? JSON.parse(local.ledger.value) : null;
    if (local.ledger && (local.ledger.type !== 'json' || !local.ledger.compareDigest || ledger.schema !== 1)) throw Error('Controle de notificacoes invalido.');
    return {state, digest: local.review?.compareDigest ?? null, ledger, ledgerDigest: local.ledger?.compareDigest ?? null};
  }

  async function set(fields) {
    const {metafieldsSet: result} = await query(SET, {metafields: fields});
    if (!result || !Array.isArray(result.metafields) || result.userErrors?.length || result.metafields.length !== fields.length) throw error(result?.userErrors?.map(e => e.message).join('; ') || 'A Shopify nao confirmou os metafields.', result?.userErrors?.[0]?.code);
    const indexed = new Map(result.metafields.map(m => [m.key, m]));
    for (const field of fields) {
      const stored = indexed.get(field.key);
      const valueMatches=field.type==='date_time' ? Math.floor(Date.parse(stored?.value)/1000)===Math.floor(Date.parse(field.value)/1000) : stored?.value===field.value;
      if (!stored || stored.namespace !== NAMESPACE || stored.type !== field.type || !valueMatches) throw Error('Resposta de gravacao incompleta ou divergente.');
    }
    return indexed;
  }

  async function publish(id, previous, operationId, origin) {
    const source = await loadAuthoritative(id);
    if (source.location?.id !== id) throw Error('Decisao de outro local.');
    const current = await read(id);
    if (current.state?.operationId !== operationId) throw error('Outra execucao modificou a sincronizacao.', 'CONFLICT');
    const state = project({...source, previous, classify, now: now(), uuid, origin});
    // Finalize the protected snapshot BEFORE publishing the event. An ACK write
    // after publishing could invalidate the Flow reservation's compareDigest.
    state.signalPending = false;
    await set(metafieldValues(state, current.digest));
    const confirmed=await read(id);
    if(JSON.stringify(confirmed.state)!==JSON.stringify(state)) throw error('Espelho divergente na leitura de confirmacao.', 'CONFLICT');
    await ensureSignal(state);
    return confirmed.state;
  }

  async function ensureSignal(state) {
    if(!emitSignals) return null;
    const event=eventFor(state);
    if(!event) return null;
    const {metaobjectUpsert: result}=await query(SIGNAL,event);
    if(!result?.metaobject||result.userErrors?.length||result.metaobject.handle!==event.handle.handle||result.metaobject.type!==event.handle.type) throw error('Estado confirmado, mas sinal nao confirmado. Sincronize novamente; nao refaca a decisao comercial.', 'SIGNAL_PENDING');
    return result.metaobject;
  }

  async function acquire(id, recoveryOperationId) {
    const before = await read(id);
    if (before.state?.operationId && before.state.operationId !== recoveryOperationId) throw error('Sincronizacao em andamento ou interrompida; recupere explicitamente a operacao.', 'LOCKED');
    const operationId = uuid();
    const blocked = {...(before.state || {schema: 1, locationId: id, status: null, cycleId: null, enteredAt: null, enrolled: false}), ready: false, operationId, updatedAt: now()};
    await set(metafieldValues(blocked, before.digest));
    return {before, operationId};
  }

  async function run(id, operation) {
    if (!enabled) return operation();
    const {before, operationId} = await acquire(id);
    // Invalidate Flow reads BEFORE changing the commercial metaobject or B2B access.
    // Failure intentionally leaves ready=false. Never roll back the real decision.
    const result = await operation();
    try { await publish(id, before.state, operationId, 'mutation'); }
    catch (cause) { throw error('Acao comercial concluida; espelho Flow requer sincronizacao. Nao repita a acao. ' + cause.message, cause.code || 'PROJECTION_FAILED'); }
    return result;
  }

  async function reconcile(id, {origin = 'backfill', recoveryOperationId} = {}) {
    if (!enabled) return {skipped: true, reason: 'disabled'};
    if (!['backfill', 'observation'].includes(origin)) throw Error('Origem de sincronizacao invalida.');
    const {before, operationId} = await acquire(id, recoveryOperationId);
    return publish(id, before.state, operationId, origin);
  }

  async function claim(id, event, kind, requestId) {
    if (!enabled) return null;
    const current = await read(id);
    const source = await loadAuthoritative(id);
    if (source.location?.id !== id || authoritativeStatus(source.location, source.decision, classify) !== current.state?.status) return null;
    const version = decisionVersion(source.decision.updatedAt);
    if (version !== current.state.decisionVersion) return null;
    const ledger = claimNotification(current.state, event, current.ledger, kind, requestId, now());
    if (!ledger) return null;
    await set([
      {ownerId: id, namespace: NAMESPACE, key: 'review', type: 'json', value: JSON.stringify(current.state), compareDigest: current.digest},
      {ownerId: id, namespace: NAMESPACE, key: 'notifications', type: 'json', value: JSON.stringify(ledger), compareDigest: current.ledgerDigest},
    ]);
    return ledger;
  }

  async function confirm(id, kind, requestId) {
    if (!enabled) return null;
    const current = await read(id);
    const ledger = confirmNotification(current.state, current.ledger, kind, requestId, now());
    await set([
      {ownerId: id, namespace: NAMESPACE, key: 'review', type: 'json', value: JSON.stringify(current.state), compareDigest: current.digest},
      {ownerId: id, namespace: NAMESPACE, key: 'notifications', type: 'json', value: JSON.stringify(ledger), compareDigest: current.ledgerDigest},
    ]);
    return ledger;
  }

  return {run, reconcile, read, claim, confirm, ensureSignal};
}
