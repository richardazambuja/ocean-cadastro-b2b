import {graphql, fetchLocation} from './api.mjs';
import {statusDoPainel, handleDoLocal} from './status.mjs';
import {createBridge} from './flow-bridge/bridge.mjs';
import {REVIEW} from './flow-bridge/operations.mjs';

const ROLLOUT = `query OceanBridgeRollout { shop { myshopifyDomain metafield(namespace:"ocean_b2b",key:"rollout") { value } } }`;
const STORE = 'mrdvrf-6a.myshopify.com';

async function configuration() {
  const data = await graphql(ROLLOUT);
  if (data.shop?.myshopifyDomain !== STORE) return {mode:'disabled'};
  const value = data.shop.metafield?.value;
  if (!value) return {mode:'disabled'};
  const parsed = JSON.parse(value);
  return ['test','production'].includes(parsed.mode) ? parsed : {mode:'disabled'};
}

async function readDecision(id) {
  const data = await graphql(REVIEW,{handle:{type:'$app:cadastro_decisao',handle:handleDoLocal(id)}});
  if (!Object.hasOwn(data,'metaobjectByHandle')) throw Error('Resposta sem decisao comercial.');
  if (!data.metaobjectByHandle) return {verified:true,localId:id,status:null,updatedAt:null};
  const record=data.metaobjectByHandle;
  const fields=Object.fromEntries(record.fields.map(f=>[f.key,f.value]));
  if (fields.local_id!==id || record.handle!==handleDoLocal(id)) throw Error('Decisao comercial de outro local.');
  return {verified:true,localId:id,status:fields.status,updatedAt:fields.alterado_em||null};
}

const bridge=createBridge({enabled:true,emitSignals:true,query:graphql,classify:statusDoPainel,loadAuthoritative:async id=>{
  const [location,decision]=await Promise.all([fetchLocation(id),readDecision(id)]);
  return {location,decision};
}});

function allowed(config,id) {
  return config.mode==='production' || (config.mode==='test' && Array.isArray(config.testLocationIds) && config.testLocationIds.includes(id));
}

export const ponteFlow={
  async run(id,operation) {
    // Missing rollout disables the bridge. A failed configuration read stops the
    // operation rather than changing a decision without invalidating its mirror.
    const config=await configuration();
    return allowed(config,id) ? bridge.run(id,operation) : operation();
  },
  async syncLoaded(locations) {
    const config=await configuration();
    const warnings=[];
    for (const location of locations) {
      if (!allowed(config,location.id)) continue;
      try {
        const current=await bridge.read(location.id);
        if (current.state) {
          // Retry only a completed projection whose native signal was interrupted.
          // The deterministic metaobject handle prevents a second cycle event.
          if (current.state.ready && !current.state.operationId && current.state.signalPending) {
            await bridge.reconcile(location.id,{origin:'observation'});
          }
          continue;
        }
        if (config.mode==='production' && Date.parse(location.createdAt)<Date.parse(config.cutover)) continue;
        const origin=config.mode==='production' && Date.parse(location.createdAt)>=Date.parse(config.cutover) ? 'observation' : 'backfill';
        await bridge.reconcile(location.id,{origin});
      } catch(e) {warnings.push(`${location.id}: ${e.message}`);}
    }
    return warnings;
  },
  async reconcile(id,options) {
    const config=await configuration();
    if (!allowed(config,id)) throw Error('Local fora do escopo de implantacao.');
    return bridge.reconcile(id,options);
  },
};
